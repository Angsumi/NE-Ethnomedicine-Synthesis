ESM 2 Data and reproducibility

Angsuman Das and Ananda Prasad
Correspondence: angsuman.das@rgu.ac.in

The combined workbook includes source records, quarantine and correction history.
Evidence tables retain original use wording and automated flags. The checked pilot
is a released input; source publications are not redistributed. Analysis scripts
reproduce results from the supplied evidence tables and caches.

Run the commands in README.md using Python 3. Source reconstruction scripts require
additional source texts; those steps are outside the default runner. Dependencies
are unpinned. The archive records the files supplied with this submission; it does
not independently verify extraction accuracy or source-level ethical compliance.
